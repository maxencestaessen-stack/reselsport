(function () {
  var CATALOG = [
    { id: "m01", src: "maillots/m01.jpg", title: "Brésil domicile", tag: "Maillot", cat: "ballon", price: "89 €" },
    { id: "m02", src: "maillots/m02.jpg", title: "Argentine rayures", tag: "Maillot", cat: "ballon", price: "95 €" },
    { id: "m03", src: "maillots/m03.jpg", title: "Rayé rouge / blanc", tag: "Maillot", cat: "ballon", price: "75 €" },
    { id: "m04", src: "maillots/m04.jpg", title: "Bleu col blanc", tag: "Maillot", cat: "ballon", price: "79 €" },
    { id: "m05", src: "maillots/m05.jpg", title: "Noir or collector", tag: "Maillot", cat: "ballon", price: "110 €" },
    { id: "m06", src: "maillots/m06.jpg", title: "Vert domicile", tag: "Maillot", cat: "ballon", price: "72 €" },
    { id: "m07", src: "maillots/m07.jpg", title: "Blanc écusson", tag: "Maillot", cat: "ballon", price: "69 €" },
    { id: "m08", src: "maillots/m08.jpg", title: "Milan domicile LS", tag: "Maillot", cat: "ballon", price: "120 €" },
    { id: "m09", src: "maillots/m09.jpg", title: "Milan — dos 11", tag: "Maillot", cat: "ballon", price: "130 €" },
    { id: "m10", src: "maillots/m10.jpg", title: "Argentine LS #5", tag: "Rétro", cat: "ballon", price: "140 €" },
    { id: "m11", src: "maillots/m11.jpg", title: "City away or", tag: "Maillot", cat: "ballon", price: "99 €" },
    { id: "m12", src: "maillots/m12.jpg", title: "Rail MLS archive", tag: "Mix", cat: "ballon", price: "85 €" },
    { id: "t-raq", src: "tees/raquette.jpg", title: "T-shirt Court", tag: "T-shirt", cat: "raquette", price: "35 €" },
    { id: "t-pad", src: "tees/raquette.jpg", title: "T-shirt Padel", tag: "T-shirt", cat: "raquette", price: "35 €" },
    { id: "t-ten", src: "tees/raquette.jpg", title: "T-shirt Service", tag: "T-shirt", cat: "raquette", price: "32 €" },
    { id: "t-bal", src: "tees/ballon.jpg", title: "T-shirt N°10", tag: "T-shirt", cat: "ballon", price: "35 €" },
    { id: "t-mot", src: "tees/moteur.jpg", title: "T-shirt Grid", tag: "T-shirt", cat: "moteur", price: "39 €" },
    { id: "t-pit", src: "tees/moteur.jpg", title: "T-shirt Pitlane", tag: "T-shirt", cat: "moteur", price: "39 €" },
    { id: "t-run", src: "tees/autres.jpg", title: "T-shirt Run Light", tag: "T-shirt", cat: "autres", price: "34 €" },
    { id: "t-out", src: "tees/autres.jpg", title: "T-shirt Trail", tag: "T-shirt", cat: "autres", price: "34 €" }
  ];
  window.SR_CATALOG = CATALOG;

  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  var grid = document.getElementById("vestiaire");
  var catPage = document.body.getAttribute("data-cat");
  if (grid) {
    var pool = catPage ? CATALOG.filter(function (x) { return x.cat === catPage; }) : CATALOG.filter(function (x) { return x.cat === "ballon" && x.tag !== "T-shirt"; });
    var items = shuffle(pool);
    var html = "";
    items.forEach(function (item, i) {
      var d = (i % 4) + 1;
      var base = item.src.replace(/\.jpg$/, "");
      var lazy = i < 4 ? "eager" : "lazy";
      var sm = item.src.indexOf("tees/") === 0 ? item.src : base + "-sm.jpg";
      html += '<article class="card reveal delay-' + d + '">' +
        '<div class="shot"><span class="tag">' + item.tag + '</span>' +
        '<img src="' + sm + '" ' +
        'srcset="' + sm + ' 420w, ' + item.src + ' 900w" ' +
        'sizes="(max-width: 700px) 48vw, (max-width: 1100px) 30vw, 22vw" ' +
        'width="900" height="1125" alt="' + item.title + '" ' +
        'loading="' + lazy + '" decoding="async" /></div>' +
        '<div class="meta"><b>' + item.title + '</b><small>' + (item.price || "") + ' · ' + item.tag + '</small>' +
        '<a class="btn buy" href="acheter.html?id=' + encodeURIComponent(item.id) + '">Acheter</a></div>' +
        '</article>';
    });
    grid.innerHTML = html;
    var sc = document.getElementById("stockCount");
    if (sc) sc.textContent = String(items.length);
  }
  var header = document.querySelector("header");
  var heroMedia = document.getElementById("heroMedia");
  var ticking = false;

  function onScroll() {
    var y = window.scrollY || 0;
    if (header) header.classList.toggle("scrolled", y > 24);
    if (heroMedia) {
      var h = heroMedia.parentElement ? heroMedia.parentElement.offsetHeight : 700;
      var p = Math.min(1, y / (h * 0.85));
      heroMedia.style.transform = "translateY(" + (y * 0.22) + "px) scale(" + (1 + p * 0.06) + ")";
      heroMedia.style.opacity = String(Math.max(0, 1 - p * 1.15));
    }
    ticking = false;
  }
  function requestTick() {
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(onScroll);
    }
  }
  onScroll();
  window.addEventListener("scroll", requestTick, { passive: true });

  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.14, rootMargin: "0px 0px -40px 0px" }
    );
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("in"); });
  }

  var form = document.getElementById("estimate-form");
  var successBox = document.getElementById("form-success");
  var errorBox = document.getElementById("form-error");
  var submitBtn = document.getElementById("form-submit");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (successBox) successBox.hidden = true;
      if (errorBox) { errorBox.hidden = true; errorBox.textContent = ""; }
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "Envoi…";
      }
      var data = new FormData(form);
      if (!data.get("form-name")) data.set("form-name", "estimation");
      fetch("/", {
        method: "POST",
        body: data,
        headers: { Accept: "application/json" }
      }).then(function (res) {
        if (res.ok) {
          form.reset();
          var prev = document.getElementById("previews");
          if (prev) prev.innerHTML = "";
          if (successBox) {
            successBox.hidden = false;
            successBox.textContent = "Demande envoyée. On te répond sous 24h.";
            successBox.scrollIntoView({ behavior: "smooth", block: "center" });
          }
        } else {
          if (errorBox) {
            errorBox.hidden = false;
            errorBox.textContent = "Envoi refusé. Le site doit être en ligne sur Netlify (pas en fichier local).";
          }
        }
      }).catch(function () {
        if (errorBox) {
          errorBox.textContent = "Pas de réseau, ou page ouverte en local. Déploie sur Netlify puis réessaie.";
          errorBox.hidden = false;
        }
      }).then(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = "Demander mon prix";
        }
      });
    });
  }

  var input = document.getElementById("photos");
  var zone = document.getElementById("dropzone");
  var previews = document.getElementById("previews");
  if (!input || !zone || !previews) return;

  var MAX_FILES = 8;
  var MAX_SIZE = 8 * 1024 * 1024;

  function render(files) {
    previews.innerHTML = "";
    Array.prototype.forEach.call(files, function (file) {
      if (!file.type || file.type.indexOf("image/") !== 0) return;
      var img = document.createElement("img");
      img.alt = file.name;
      img.src = URL.createObjectURL(file);
      previews.appendChild(img);
    });
  }

  function filterList(fileList) {
    var ok = [];
    Array.prototype.forEach.call(fileList, function (file) {
      if (file.type.indexOf("image/") !== 0) return;
      if (file.size > MAX_SIZE) return;
      if (ok.length < MAX_FILES) ok.push(file);
    });
    var dt = new DataTransfer();
    ok.forEach(function (f) { dt.items.add(f); });
    input.files = dt.files;
    render(input.files);
  }

  input.addEventListener("change", function () {
    filterList(input.files);
  });

  ["dragenter", "dragover"].forEach(function (evt) {
    zone.addEventListener(evt, function (e) {
      e.preventDefault();
      zone.classList.add("dragover");
    });
  });
  ["dragleave", "drop"].forEach(function (evt) {
    zone.addEventListener(evt, function () {
      zone.classList.remove("dragover");
    });
  });
  zone.addEventListener("drop", function (e) {
    e.preventDefault();
    if (e.dataTransfer && e.dataTransfer.files) filterList(e.dataTransfer.files);
  });
})();

(function () {
  var CATALOG = window.SR_CATALOG || [];
  var buyRoot = document.getElementById("buy-product");
  if (buyRoot) {
    var params = new URLSearchParams(window.location.search);
    var id = params.get("id");
    var item = CATALOG.filter(function (x) { return x.id === id; })[0] || CATALOG.filter(function (x) { return x.tag === "T-shirt"; })[0];
    if (item) {
      var img = buyRoot.querySelector("[data-img]");
      var title = buyRoot.querySelector("[data-title]");
      var price = buyRoot.querySelector("[data-price]");
      var tag = buyRoot.querySelector("[data-tag]");
      var hidden = document.getElementById("produit-field");
      if (img) { img.src = item.src; img.alt = item.title; }
      if (title) title.textContent = item.title;
      if (price) price.textContent = item.price;
      if (tag) tag.textContent = item.tag;
      if (hidden) hidden.value = item.title + " (" + item.id + ")";
    }
  }
  var order = document.getElementById("order-form");
  if (order) {
    order.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok = document.getElementById("form-success");
      var err = document.getElementById("form-error");
      var btn = order.querySelector("[type=submit]");
      if (ok) ok.hidden = true;
      if (err) err.hidden = true;
      if (btn) { btn.disabled = true; btn.textContent = "Envoi…"; }
      var data = new FormData(order);
      if (!data.get("form-name")) data.set("form-name", "commande");
      fetch("/", { method: "POST", body: data, headers: { Accept: "application/json" } })
        .then(function (res) {
          if (res.ok) {
            order.reset();
            if (ok) { ok.hidden = false; ok.textContent = "Commande reçue. On te confirme taille et paiement par mail."; }
          } else if (err) {
            err.hidden = false;
            err.textContent = "Envoi refusé. Page à ouvrir sur Netlify, pas en local.";
          }
        })
        .catch(function () {
          if (err) { err.hidden = false; err.textContent = "Hors-ligne ou page locale. Déploie sur Netlify."; }
        })
        .then(function () {
          if (btn) { btn.disabled = false; btn.textContent = "Réserver cette pièce"; }
        });
    });
  }
})();
